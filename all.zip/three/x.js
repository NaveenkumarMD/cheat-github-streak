let arr=[1,2,3,4]
let odd=arr.filter(val=>{
    return val%2!=0
})
console.log(odd)
//[1,3]